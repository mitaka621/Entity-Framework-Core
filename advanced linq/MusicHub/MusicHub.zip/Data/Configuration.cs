﻿namespace MusicHub.Data
{
    public static class Configuration
    {
        public static string ConnectionString =
            "Server=.;Database=MusicHub;Encrypt=True;Integrated Security=True;TrustServerCertificate=True";
    }
}
