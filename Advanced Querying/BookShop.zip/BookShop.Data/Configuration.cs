﻿namespace BookShop.Data
{
    internal class Configuration
    {
        internal static string ConnectionString
            => "Server=.;Database=BookShop;Encrypt=True;Integrated Security=True;TrustServerCertificate=True";

    
    }
}
