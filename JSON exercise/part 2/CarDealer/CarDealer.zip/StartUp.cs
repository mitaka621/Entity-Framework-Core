﻿using CarDealer.Data;
using CarDealer.DTOs;
using CarDealer.Models;
using Newtonsoft.Json;
using System.Text.Json.Serialization;
using System.Xml.Schema;

namespace CarDealer
{
    public class StartUp
    {
        public static void Main()
        {
            CarDealerContext context = new CarDealerContext();
            string file = File.ReadAllText("../../../Datasets/customers.json");
            Console.WriteLine(ImportCustomers(context, file));
        }

        public static string ImportSuppliers(CarDealerContext context, string inputJson)
        {
            var supp = JsonConvert.DeserializeObject<Supplier[]>(inputJson);

            context.Suppliers.AddRange(supp);
            context.SaveChanges();
            return $"Successfully imported {supp.Length}.";
        }
        public static string ImportParts(CarDealerContext context, string inputJson)
        {
            var Part = JsonConvert.DeserializeObject<Part[]>(inputJson).Where(x=>context.Suppliers.Any(y=>y.Id==x.SupplierId)).ToArray();

            context.Parts.AddRange(Part);
            context.SaveChanges();
            return $"Successfully imported {Part.Length}.";
        }

        public static string ImportCars(CarDealerContext context, string inputJson)
        {
            var cars = JsonConvert.DeserializeObject<CarDTO[]>(inputJson);

            foreach (var item in cars)
            {
                Car tempCar = new Car()
                {
                    Make = item.Make,
                    Model = item.Model,
                    TraveledDistance = item.TraveledDistance,
                    
                };
                foreach (var part in item.PartsCars)
                {
                    if (context.Parts.Any(p => p.Id == part))
                    {
                        tempCar.PartsCars.Add(new PartCar() { PartId = part });
                    }
                }

                context.Cars.Add(tempCar);
            }


            context.SaveChanges();

            return $"Successfully imported {cars.Length}.";
        }

        public static string ImportCustomers(CarDealerContext context, string inputJson)
        {
            var Customer = JsonConvert.DeserializeObject<Customer[]>(inputJson);

            context.Customers.AddRange(Customer);
            context.SaveChanges();
            return $"Successfully imported {Customer.Length}.";
        }
    }
}