﻿namespace ProductShop.Data
{
    public static class Configuration
    {
        public const string ConnectionString = @"Server=.;Database=ProductShop;Encrypt=True;Integrated Security=True;TrustServerCertificate=True";
    }
}
