﻿namespace CarDealer.Data
{
    public static class Configuration
    {
        public const string ConnectionString = @"Server=.;Database=CarDealer;Encrypt=True;Integrated Security=True;TrustServerCertificate=True";
    }
}
