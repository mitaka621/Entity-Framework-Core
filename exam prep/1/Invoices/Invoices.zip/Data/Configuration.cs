﻿namespace Invoices.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=.;Database=Invoices;Encrypt=True;Integrated Security=True;TrustServerCertificate=True";
    }
}
